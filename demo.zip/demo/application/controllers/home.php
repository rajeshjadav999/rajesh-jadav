<?php ob_start();
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Home extends Template {

	public function __construct()
	{
      parent::__construct();
	  	header('P3P:CP="IDC DSP COR ADM DEVi TAIi PSA PSD IVAi IVDi CONi HIS OUR IND CNT"');
      $this->load->helper('form');
      $this->load->library('file_uploader');
      $this->load->model('user_model');
      $this->load->model('common_model');
		//Template settings
		$this->set_template("user/template");
		$this->set_header_path('user/blocks/header');
		$this->set_footer_path('user/blocks/footer');
		$this->session->set_userdata("CURRENT_PAGE","");
		$this->session->unset_userdata('artist');
		$this->set_title('Home');
	}
	public function index()
	{	
		$this->view("user/home");
	}
	public function login() 
	{
		if ($this->session->userdata("user_id"))
		{
			redirect('home','refresh');
			exit;
		}
		$data = array();
		$this->set_title('Login');
		$data['login'] = $this->session->flashdata("login")?$this->session->flashdata("login"):array();
	 	$data['scoll_button'] = "no";
		$this->view("user/login",$data);
	}
	public function register() 
	{
		$data = array();
		$data['mode']= "add";
		$this->set_title('Register');
		$data['user'] = $this->session->flashdata("user")?$this->session->flashdata("user"):array();
	 	//$this->load->model('common_model');
		$this->view("user/registration",$data);
	}
	public function do_register()
	{
		$mode = $_POST['mode'];
		$id = $_POST['id'];
		$fields = array ( "first_name","user_name","last_name","email","password","dob","gender","phone_no","current_image");
		$data		= array();
		foreach( $fields as $field )
		{
			$data[$field] = trim($this->input->post($field));
		}
		$data = $this->get_post_values($fields); 
		if($mode == "add")
		{
		$config = array(
			array
			(
				'field'   => 'first_name', 
				'label'   => 'First Name', 
				'rules'   => 'trim|required'
			),
			array
			(
				'field'   => 'last_name', 
				'label'   => 'Last Name', 
				'rules'   => 'trim|required'
			),
			array
			(
				'field'   => 'user_name', 
				'label'   => 'User Name', 
				'rules'   => 'trim|required'
			),
			array
			(
				'field'   => 'email', 
				'label'   => 'Email', 
				'rules'   => 'required|trim|xss_clean|is_unique[users.email]'
			),
			array
			(
				'field'   => 'gender', 
				'label'   => 'Gender', 
				'rules'   => 'trim|required'
			),
			array
			(
				'field'   => 'phone_no', 
				'label'   => 'Phone no', 
				'rules'   => 'trim|required|numeric|regex_match[/^[0-9]{10}$/]'
			),
			
		);   
		}
		else {
		$config = array(
			array
			(
				'field'   => 'first_name', 
				'label'   => 'First Name', 
				'rules'   => 'trim|required'
			),
			array
			(
				'field'   => 'last_name', 
				'label'   => 'Last Name', 
				'rules'   => 'trim|required'
			),
			array
			(
				'field'   => 'user_name', 
				'label'   => 'User Name', 
				'rules'   => 'trim|required'
			),
			
			
		);   
		}
	 	$this->form_validation->set_rules($config);
	   if ( $this->form_validation->run() == FALSE) 
		{
			$this->session->set_flashdata( "errors", validation_errors());
			$this->session->set_flashdata("user",$data);			
			redirect($_SERVER["HTTP_REFERER"]);
			return;	
		}
		else
		{		
			if($mode=="add")
			{
			$data['password'] = hash("SHA512", $data['password']);
			unset($data['current_image']);
			$this->common_model->set_fields( $data );
			$user_saved_id = $this->common_model->save("users");
			$this->session->set_flashdata( "success", "success" );
					$this->session->set_flashdata("login",$data);			
					redirect($_SERVER["HTTP_REFERER"]);
					return;	
					
			}else{

			if (!empty($_FILES) && array_key_exists("image", $_FILES) && $_FILES['image']["name"] != '') //validate image
			{
				$path = './assets/upload/profile_picture/original/';
				$this->file_uploader->set_default_upload_path($path);		   
			 	 if( $_FILES['image']['type'] == 'image/jpg' || $_FILES['image']['type'] == 'image/jpeg' ||  $_FILES['image']['type'] == 'image/png')
				 {
				 		$_FILES['image']["name"] = str_replace(' ','_',$_FILES['image']["name"]);
						$post_image = $this->file_uploader->upload_other_file('image');
						if($post_image['status'] == 200)
						{
							    	
			   						
			   					$this->load->library('image_lib');
		
             
			              if(isset($_POST['current_image']) && $_POST['current_image'])
		                  {
		                  	    @unlink('./assets/upload/profile_picture/original/'.$_POST['current_image']);
		                  	    
		                  }   
			   				//$this->image_lib->initialize($config_manip);
			   				//$this->image_lib->resize();
			   				//$errors = $this->image_lib->display_errors();
			   				$data['profile_picture'] = $post_image['data'];
						}
						else 
						{
							$this->session->set_flashdata("errors", "Invalid file.");
							$this->session->set_flashdata( "user_info",$data);	
			  				redirect($_SERVER["HTTP_REFERER"]);
							return;
						}
				}
				else
			   {
			   	$this->session->set_flashdata("errors", "Please upload a valid format file jpg, jpeg or png. ");
			   	$this->session->set_flashdata( "linkPost",$data);
					redirect($_SERVER["HTTP_REFERER"]);	
					return;	
			  	}
				
				
				
			}
			else 
			{
				$data['profile_picture'] = $data['current_image'];
			}
			unset($data['current_image']);
			$this->common_model->set_fields($data);			
			$this->common_model->updateData('users', array( "id" => $id ) );
  			$this->session->set_flashdata("success", get_message("authentication_admin_profile_update_success"));
  			
	   		redirect($_SERVER["HTTP_REFERER"]);
	   		return;
			}
					
			
		}
	}	

	public function do_login(){
		$fields = array ('email','password');		
		foreach($fields as $field){
		$data[$field] = trim($this->input->post($field));
		}
		$config = array(
			array(
               'field'   => 'email', 
           	  'label'   => 'Email', 
               'rules'   => 'trim|required|valid_email'
           	 ),
            array(
               'field'   => 'password', 
           	  'label'   => 'Password', 
               'rules'   => 'trim|required'
           	 )
	   		);
			$this->form_validation->set_rules($config);
			if($this->form_validation->run() == FALSE){
				$this->session->set_flashdata( "errors", validation_errors());
				$this->session->set_flashdata("login",$data);			
				redirect($_SERVER["HTTP_REFERER"]);
				return;	
			}else{
				$data['password'] = hash("SHA512", $data['password']);
				$this->user_model->set_fields($data);			
				$row  = $this->user_model->do_login();
				//print_r($row);exit;
				//echo $this->db->last_query();exit;
				if($row){
				
				
				$userData = array(
												"user_name"=>$row['user_name'],
												"user_id"=>$row['id'],
												"email"=>$row['email'],
												"login" =>true
												);					
					
				$this->session->set_userdata($userData);
				
				if($this->session->userdata('user_id')){
					redirect('home');					
				}
				}else{
					$this->session->set_flashdata( "errors", "Invalid Email or Password" );
					$this->session->set_flashdata("login",$data);			
					redirect($_SERVER["HTTP_REFERER"]);
					return;	
				}
			}
	}	 
	
	public function user_list() {

		$user_id = $this->session->userdata('user_id');
		$data['user_list'] = $this->user_model->get_user_list();
		//print_r($data['user_list']);exit;
		$this->view("user/user_list", $data);
	}	
	public function delete_record($id){
		$data['user_id']= $id;
		$this->user_model->set_fields($data);
		$user = $this->user_model->get_user_detail();
		@unlink('./assets/upload/profile_picture/original/'.$user['profile_picture']);
		$this->common_model->remove('users',array('id'=>$id));
				echo "1";exit;	
	}
	public function edit($id){
		$data = array();
		$this->set_title('Edit');
		$data['user_id']= $id;
		$data['mode']= "edit";
		$this->user_model->set_fields($data);
		$data['user'] = $this->user_model->get_user_detail();
	 	
		$this->view("user/registration",$data);
	}
}
?>