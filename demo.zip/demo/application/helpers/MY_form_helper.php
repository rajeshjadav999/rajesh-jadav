<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');


function drop_down( $name, $arr, $sel='' ,$extra='' )
{
	$str = '<select name="'.$name.'"'.$extra.' >';

	foreach( $arr as $key=>$val )
	{
		if ( $key == $sel )
		{
			$str .= '<option value="'.$key.'" selected="selected" >'.$val.'</option>';
		}
		else
		{
			$str .= '<option value="'.$key.'">'.$val.'</option>';
		}	
	}		
		
	$str .= '</select>'; 
	return $str;
}