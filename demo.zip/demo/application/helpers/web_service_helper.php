<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

if ( ! function_exists('json_response') )
{


	function json_response( $status,$message,$data,$total_page="",$page="" )
	{
		$res_data 					= array();
		$res_data [ "success" ] 	= $status;
		$res_data [ "message" ] 	= $message;
		$res_data [ "data" ]		= $data;
		if($total_page !="")
		{
			$res_data [ "total_page" ]		= "$total_page";
		}
		if($page !="")
		{
			$res_data [ "page" ]		= "$page";
		}
		
		return json_encode( $res_data );
	}
}
?>