<?php   if (!defined('BASEPATH')) exit('No direct script access allowed');
	 class user_model extends MY_Generic_Model{
	  
	  //initialize
	  
	  	public function __construct()
	  	{
		  	parent::__construct();
	  	
	  	}

	public function do_login()
	{
		

		$query  = $this->query("SELECT id,user_name,email FROM ".$this->tables["users"]." WHERE email='".$this->data['email']."' AND password='".$this->data['password']."' ") ;

	
   		if($query->num_rows > 0)
		{
			$res=$query->row_array();
			return $res;
		}	
		else 
		{
			return false;		
	 	}  
		
   }
   	public function get_user_list()
	{
		

		$query  = $this->query("SELECT * FROM ".$this->tables["users"]." ") ;

	
   		if($query->num_rows > 0)
		{
			$res=$query->result_array();
			return $res;
		}	
		else 
		{
			return false;		
	 	}  
		
   }
   public function get_user_detail()
	{
		

		$query  = $this->query("SELECT * FROM ".$this->tables["users"]."  WHERE id='".$this->data['user_id']."'") ;

	
   		if($query->num_rows > 0)
		{
			$res=$query->row_array();
			return $res;
		}	
		else 
		{
			return false;		
	 	}  
		
   }
  
}
	
?>