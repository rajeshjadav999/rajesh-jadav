<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Common_model extends MY_Generic_Model{

	//initialize

	public function __construct()
	{
		  	parent::__construct();
		  	
	}
	
	/*
	 * Will save data to the table. NOTE: set data before calling this function
	 * Params: $tableName - String
	 * Return: Last inserted Id;
	 */
	public function save($tableName)
	{		
	
		 $user_id = $this->insert( $this->tables[$tableName], $this->data );
		 //echo $this->db->last_query();exit;
		 return $user_id;	
	}	
	
	/*
	 * Will update data to the table. NOTE: set data before calling this function
	 * Params: $tableName - String, $where - Array with condition as key and value
	 * Return: true OR false
	 */
	public function updateData($tableName, $where )
	{
		$return = $this->update( $this->tables[$tableName],$this->data, $where );
		
		//echo $this->db->last_query(); exit;
		return $return;
	}
	
	/*
	 * Will delete records from table
	 * Params: $tableName - String, $where - Array with condition as key and value
	 * Return: true OR false
	 */
	public function remove($tableName, $where )
	{
		return $this->delete( $this->tables[$tableName],$where );
	}
	/*
	 * Will delete multiple records from table
	 * Params: $tableName - String, $where - Array with value, $where = array(4,7)
	 * Return: true OR false
	 */
	public function deleteMultiple($tableName, $where )
	{
		
		return $this->delete_multiple( $this->tables[$tableName],$where );
	}
	/*
	* Will return no of categories
	* params : table name
	*/
	public function getCountRecords($tableName)
	{
		$query 	= "SELECT COUNT(id) as total FROM ".$this->tables[$tableName];
		
		$result 	= $this->query_result($query);
		
		return $result[0]->total;
			
	} 

	public function isAunthenticateOperation($tableName)
	{
		$query 	= "SELECT COUNT(id) as total FROM ".$this->tables[$tableName]." WHERE id = ".$this->data['id']." AND company_user_id='".$this->data['user_id']."'";
		
		$result 	= $this->query_result($query);
		
		if (  $result[0]->total > 0 )
		{
			return true;	
		}
		return false;
	}	
	
	public function get_subscription_fee()
	{
		$query=$this->query("Select amount From ".$this->tables['subscription_fee']." Limit 1");
		if($query->num_rows > 0)
		{
			$res=$query->row_array();
			return $res['amount'];
		}	
		else 
		{
			return false;		
	 	}
	}	
	
		
}