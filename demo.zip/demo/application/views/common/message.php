<?php
	$errors = $this->session->flashdata("errors");
	
	if ( $errors)
	{ ?>
		 <div class="alert alert-danger alert-dismissable"> 
           <?php echo $errors; ?>
       </div>
		
	<?php } 


	$success = $this->session->flashdata("success");
	
	if ( $success)
	{
		?>
		 <div class="alert alert-success alert-dismissable"> 
           <?php echo $success; ?>
       </div>
		
	<?php } 

?>
