<div class="header">
	<div class="hwrapper">
		<div class="headleft">
				<a href="<?php echo base_url(); ?>" >
					<h1>demo</h1>
				</a>
		</div>
		<div class="headerright-new">
				<div id='cssmenu'>
										<ul>
									
										   <li><a href="<?php echo base_url('home/login');?>">Login</a></li>
										   <li><a href="<?php echo base_url('home/register');?>">Register</a></li>
										    <li><a href="<?php echo base_url('home/user_list');?>">User</a></li>
										</ul>
					
								
				</div>
		</div>
		<div class="clear"></div>
	</div>
</div>	
	