<div id="main" style="min-height:708px;">
    <div class="container" >
      <div class="row">
	  	<div class="col01 center">
        	<h1>Welcome to demo</h1>
			
		</div>
		
		
      </div>
    </div>
  </div>
  <!-- #main -->