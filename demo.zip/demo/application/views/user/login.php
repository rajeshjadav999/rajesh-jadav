<link rel="stylesheet" href="<?php echo base_url('assets/css/new-styles.css'); ?>" type="text/css" />

<div class="sep"></div>

<div class="main">
	<div class="frmmid">
		<div class="frmtit">Sign In</div>


				  	<div class="frmpedd">
				   	<?php echo form_open(base_url('home/do_login'));  ?>
				   	<?php echo $this->load->view('common/message'); ?>
				  			<div class="frmlbl">Email</div>
				    			<input type="text" class="frmfild"  style="border-radius:0px" name="email" tabindex="1" value="" id="exampleInputEmail1" >
				  			
				  			<div class="frmlbl">Password </div>
				    		<input type="password" name="password"  class="frmfild" tabindex="2" id="exampleInputPassword1" >
				  			
				  			<div class="buttonmain">
				  				<button type="submit"  class="button" >Sign in</button> 
				  			</div>
				  			
						<?php echo form_close(); ?>
				  	</div>
				</div>  
</div>
  
<div class="sep"></div>
