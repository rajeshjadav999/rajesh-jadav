<div class="rrs-blog">
	<div class="lable">Rss Blog Feed Url</div>
	<input type="text" class="fullinput" name="rss_blog_url[]" value="" placeholder="Rss Blog Feed Url" />
</div>
<br>