<?php
	$physical = array("Muscle Weakness"=>"Muscle Weakness",
												"Numbness"=>"Numbness",
												"Pressure Sore"=>"Pressure Sore",
												"Pneumonia"=>"Pneumonia",
												"Incontinence"=>"Incontinence",
												"Speech Loss"=>"Speech Loss",
												"Apraxia"=>"Apraxia",
												"Difficulty with daily activities"=>"Difficulty with daily activities",
												"Balance issue"=>"Balance issue",
												"Vision Loss"=>"Vision Loss",
												"Hearing Loss"=>"Hearing Loss",
												"Loss of appetite"=>"Loss of appetite",
												"Vertigo or dizziness"=>"Vertigo or dizziness",
												"Seizure"=>"Seizure",
												"Other"=>"Other"
												);	 
	$cognitive = array("Perception Disorder"=>"Perception Disorder",
											"Dementia"=>"Dementia",
											"Aphasia"=>"Aphasia",
											"Attention deficit"=>"Attention deficit",
											"Anosognosia (Unaware of the disability)"=>"Anosognosia (Unaware of the disability)",
											"Hemispatial Neglect"=>"Hemispatial Neglect",
											"Other"=>"Other"
												);						
	$emotional = array("Depression"=>"Depression",
												"Anxiety"=>"Anxiety",
												"Panic attack"=>"Panic attack",
												"Flat affect (Can not express emotion)"=>"Flat affect (Can not express emotion)",
												"Mania"=>"Mania",
												"Apathy"=>"Apathy",
												"Psychosis"=>"Psychosis",
												"Decreased ability to express through body language and facial expression"=>"Decreased ability to express through body language and facial expression",
												"Other"=>"Other"
					
										 );	
										 
	$symptoms = array("physical"=>"Physical","cognitive"=>"Cognitive","emotional"=>"Emotional");									 																			
?>

<div class="clear"></div>
<div class="gift paddingbtm">
	<div class="lable">Symptoms</div>
	 <select class="fullinput symptoms" name="symptoms[]" onchange="return getVal(this.value,<?php echo $number ?>);" >
	 	<option value="">Select</option>
		<?php 
				foreach($symptoms as $key=>$val)
				{
		?>
				<option value="<?php echo $key; ?>"><?php echo $val; ?></option>
		<?php			
				}
		 ?>	
	</select>	
</div>

<div class="gift paddingbtm">
	<div class="lable">Symptoms Detail</div>
	 <select class="fullinput" name="symptoms_value[]"  id="symptoms_value_<?php echo $number ?>">									
	 </select>	
</div>
