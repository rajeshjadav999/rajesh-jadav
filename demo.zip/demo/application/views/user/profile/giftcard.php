 <div class="main">
  <div class="pull-left"><a href="<?php echo base_url('account/giftcard'); ?>">My Giftcards</a> |
  <a href="<?php echo base_url('account/podcast'); ?>">My Podcasts</a> |
<a href="<?php echo base_url('account/profile'); ?>">Edit Profile</a> |   
   <a href="<?php echo base_url('account/changepassword'); ?>">Change Password</a> |
   <a href="<?php echo base_url('account/logout');?>">Logout</a> 	 </div><div class="clear"></div>
   
    <div class="container">
	
	
      <div class="row">
	  
		<div class="currentpage">
			<span>My Giftcards</span>
		</div>
		
		<div class="tabmain-title tabtitpedd">
			<div class="tabmain-tleft"></div>
			<div class="tabmain-tright">
				
				<div class="clear"></div>
				
				  
			</div>
			<div class="clear"></div>
		</div>
		
		
		<div class="tblmain">
		<?php if(empty($giftcard))
				{?>
				<div class="currentpage">
			   <div class="text-center">No Giftcard Available.</div>
					<div class="clear"></div>
					</div>
			<?php }else{?>
			<div class="groupmain">
				<div class="group01-tit widthallgift">Giftcard No </div>
				<div class="group01-tit widthall  right">Original Balance </div>
				<div class="group01-tit widthall right">Current Balance</div>	
				<div class="clear"></div>
				
			
				<?php
				if(!empty($giftcard))
				{
				
					foreach($giftcard as $pre)
					{ 
					
					?>
				<div class="group-conmain">
					<div class="group01 widthallgift"><?php  echo $pre['giftcard_identification'];?></div>
					
					<div class="group01 widthall right"><?php echo $pre['giftcard_balance'];?></div>
					<div class="group01 widthall right"><?php $bal=$pre['giftcard_balance']-$pre['giftcard_usage'];
					echo $bal.'.00';?></div>
					
					<div class="clear"></div>
				</div>
					<?php	
					}					
				} }?>
				
				
			</div>
		</div>
      </div>
    </div>
  </div>	