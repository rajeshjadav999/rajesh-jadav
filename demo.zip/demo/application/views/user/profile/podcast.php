 <div class="main">
  <div class="pull-left"><a href="<?php echo base_url('account/giftcard'); ?>">My Giftcards</a> |
  <a href="<?php echo base_url('account/podcast'); ?>">My Podcasts</a> |
<a href="<?php echo base_url('account/profile'); ?>">Edit Profile</a> |   
   <a href="<?php echo base_url('account/changepassword'); ?>">Change Password</a> |
   <a href="<?php echo base_url('account/logout');?>">Logout</a>  </div>	<div class="clear"></div>
    <div class="container">
	
      <div class="row">
	  
		<div class="currentpage">
			<span>My Podcasts</span>
		</div>
		
		<div class="tabmain-title tabtitpedd">
			<div class="tabmain-tleft"></div>
			<div class="tabmain-tright">
				
				<div class="clear"></div>
				
				  
			</div>
			<div class="clear"></div>
		</div>
		
		
		<div class="tblmain">
		<?php if(empty($podcast))
				{?>
				<div class="currentpage">
			   <div class="text-center">No Podcast Available.</div>
					<div class="clear"></div>
					</div>
			<?php }else{?>
			<div class="groupmain">
				<div class="group01-tit widthallgift space ">Podcast </div>
				<div class="group01-tit widthall right space">Price </div>
				<div class="group01-tit widthall">Date</div>
			
				
				<div class="clear"></div>
				
			
				<?php
				
				if(!empty($podcast))
				{
				
					foreach($podcast as $pre)
					{ 
					
					?>
				<div class="group-conmain">
					<div class="group01 widthallgift space"><?php echo $pre['title'];?></div>
					<div class="group01 widthall right space"><?php echo $pre['price'];?></div>
					<div class="group01 widthall"><?php echo date('d M, Y',strtotime($pre['date']));?></div>
					
					<div class="clear"></div>
					
				</div>
					<?php	
					}					
				}
			}?>
				
			</div>
		</div>

      </div>
	  
    </div>
  </div>
  



		
		