<?php
	$physical = array("Muscle Weakness"=>"Muscle Weakness",
												"Numbness"=>"Numbness",
												"Pressure Sore"=>"Pressure Sore",
												"Pneumonia"=>"Pneumonia",
												"Incontinence"=>"Incontinence",
												"Speech Loss"=>"Speech Loss",
												"Apraxia"=>"Apraxia",
												"Difficulty with daily activities"=>"Difficulty with daily activities",
												"Balance issue"=>"Balance issue",
												"Vision Loss"=>"Vision Loss",
												"Hearing Loss"=>"Hearing Loss",
												"Loss of appetite"=>"Loss of appetite",
												"Vertigo or dizziness"=>"Vertigo or dizziness",
												"Seizure"=>"Seizure",
												"Other"=>"Other"
												);
	sort($physical);												 
	$cognitive = array("Perception Disorder"=>"Perception Disorder",
											"Dementia"=>"Dementia",
											"Aphasia"=>"Aphasia",
											"Attention deficit"=>"Attention deficit",
											"Anosognosia (Unaware of the disability)"=>"Anosognosia (Unaware of the disability)",
											"Hemispatial Neglect"=>"Hemispatial Neglect",
											"Other"=>"Other"
												);
	sort($cognitive);																	
	$emotional = array("Depression"=>"Depression",
												"Anxiety"=>"Anxiety",
												"Panic attack"=>"Panic attack",
												"Flat affect (Can not express emotion)"=>"Flat affect (Can not express emotion)",
												"Mania"=>"Mania",
												"Apathy"=>"Apathy",
												"Psychosis"=>"Psychosis",
												"Decreased ability to express through body language and facial expression"=>"Decreased ability to express through body language and facial expression",
												"Other"=>"Other"
					
										 );
	sort($emotional);											 																				
?>

<script type="text/javascript" src="<?php echo base_url('assets/js/vendors/profile.js'); ?>"></script>
<div class="main">
    <div class="container">
	
      <div class="row">
	
		<div class="tabmain">
			<div class="tab">
				<a href="#" class="active">Edit Profile</a>
			</div>
			<div class="clear"></div>
			
			<div id="tabs-1" class="tabcontain">
				<?php echo $this->load->view('common/message'); ?>
				<div class="sblue">
					<a href="javascript:void(0)" onclick="changeBasic();" >Basic Information</a>
					<a href="javascript:void(0)" onclick="changeAddress();" >Address & Contacts</a>                       
					<a href="javascript:void(0)" onclick="changeSocial();" >Social Information</a>                          
					<?php if($user['role'] == 'caregivers' || $user['role'] == 'survivors' || $user['designation'] == 'survivor' || $user['designation'] == 'caregiver') { ?><a href="javascript:void(0)" onclick="changeMedical();" >Medical History</a> <?php } ?>                    
					<?php if($user['role'] == 'professionals'){ ?> <a href="javascript:void(0)" onclick="changeProfessional();" >Professional History</a> <?php } ?>
					<?php if($user['role'] == 'volunteer') { ?> <a href="javascript:void(0)" onclick="changeVolunteer();" >Volunteer Resume</a> <?php } ?>
				</div>
				<?php
			
					$attributes = array('id' => 'add_form', 'name' => 'add_form', 'method'=>'POST','enctype'=>"multipart/form-data");				   	
   				echo form_open(base_url('home/do_register'),$attributes); 
   			?>			
   			<?php
   				$healing_interest = array(
										"Occupational Therapy"=>"Occupational Therapy",
										"Pharmacy"=>"Pharmacy",
										"Physical Therapy"=>"Physical Therapy",
										"Respiratory Therapy"=>"Respiratory Therapy",
										"Diet"=>"Diet",
										"Speech therapy"=>"Speech therapy",
										"Acupuncture"=>"Acupuncture",
										"Tai Chi"=>"Tai Chi",
										"Guided Imagery"=>"Guided Imagery",
										"Massage therapy"=>"Massage therapy",
										"Hippotherapy"=>"Hippotherapy",
										"Psychological counseling"=>"Psychological counseling",
										"Other"=>"Other"
								);
					sort($healing_interest);			
   			
   			?>
   			<input type="hidden" name="id" value="<?php echo $this->session->userdata['id'];?>" >	
   			<div id="basicinfo"> <!--- Basic Info Start -->
						<div class="gift paddingbtm">
							<div class="lable">User Name</div>
							<input type="text" class="fullinput" name="username" value="<?php if(isset($user['username'])){ echo htmlentities(trim($user['username']));} ?>" placeholder="User Name" />
						</div>				
						
						<div class="gift paddingbtm">
							<div class="lable">Email</div>
							<input type="text" class="fullinput" name="email" value="<?php if(isset($user['email'])){ echo htmlentities(trim($user['email']));} ?>" placeholder="Email" />
						</div>
						<div class="clear"></div>
						
						
						<div class="gift paddingbtm">
							<div class="lable">First Name</div>
							<input type="text" class="fullinput" name="first_name" placeholder="First Name" value="<?php if(isset($user['first_name'])){ echo htmlentities(trim($user['first_name']));} ?>" />
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Last Name</div>
							<input type="text" class="fullinput" name="last_name" placeholder="Last Name" value="<?php if(isset($user['last_name'])){ echo htmlentities(trim($user['last_name']));} ?>" />
						</div>
						<div class="clear"></div>
						
						<div class="gift paddingbtm">
							<div class="lable">Gender</div>
							<select name="gender" class="fullinput">
									<option value="">Select</option>
									<option value="0" <?php if($user['gender'] == '0'){ echo "selected='selected'"; } ?>>Male</option>
									<option value="1" <?php if($user['gender'] == '1'){ echo "selected='selected'"; } ?>>Female</option>
							</select>						
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Image
										<?php if(isset($user['picture']) && $user['picture'] != '' )
									  			{ 
									   ?>				
									  					<a href="<?php echo base_url('assets/upload/users/original/'.$user['picture']);?>"  style="overflow: hidden;position: absolute;padding: 5px;line-height: 10px;margin-left: 5px;" class="btn-effect-ripple btn-xs btn-info actin-btn action-space"  target="_blank"><i class="fa fa-eye"></i></a>
														<input type="hidden" name="current_image" value="<?php echo $user['picture']; ?>"  />                 
									   <?php }
						 		  				else
						 		  				{ 
						 		  		?> 
						 		  						<a href="<?php echo base_url('assets/images/No_Image.jpg');?>"  style="overflow: hidden;position: absolute;padding: 5px;line-height: 10px;margin-left: 5px;" class="btn-effect-ripple btn-xs btn-info actin-btn action-space" target="_blank"><i class="fa fa-eye"></i></a>                 
								 	   <?php
												}  
									   ?>	
							</div>
							<input name="picture" type="file"  id="image" value="" style="padding:8px"  class="fullinput" />
						</div>
				</div>  <!--- Basic Info End -->	
				<div class="clear"></div>
				
				<div id="medicalhistory" style="display:none" > <!--- Medical History Start -->	
				<?php 
							$stroke_type=array(
													"Ishemic"=>"Ishemic",
													"Hemorrhagic"=>"Hemorrhagic",
													"TIA"=>"TIA",
													"Other"=>"Other"
												);
							sort($stroke_type);					
							$stroke_location=array(
													"Cerebellum"=>"Cerebellum",
													"Brain Stem"=>"Brain Stem",
													"Basal Ganglia"=>"Basal Ganglia",
													"Cortex"=>"Cortex",
													"Cranium"=>"Cranium",
													"Occiptal Lobe"=>"Occiptal Lobe",
													"Parietal Lobe"=>"Parietal Lobe",
													"Frontal Lobe"=>"Frontal Lobe",
													"Temporal Lobe"=>"Temporal Lobe"

								);
							sort($stroke_location);	
							
						?>
				
						<div class="gift paddingbtm">
							<div class="lable">Injury Date</div>
							<input type="text" class="fullinput" style="width:250px;"  id="injury_date" name="injury_date" value="<?php echo date('d/m/Y',strtotime($user['injury_date'])); ?>"  placeholder="MM/DD/YYYY" />
						
						</div>
						
						
						<div class="gift paddingbtm">
							<div class="lable">Location of Injury</div>
							<input type="text" class="fullinput" name="location_of_injury" value="<?php if(isset($user['location_of_injury']) && $user['location_of_injury'] != 0){ echo htmlentities(trim($user['location_of_injury']));} ?>" placeholder="Location of Injury" />
						</div>
						
				
						
						<div class="clear"></div>
						
						<div class="gift paddingbtm">
							<div class="lable">Treatments</div>
							<input type="text" class="fullinput" name="treatments" value="<?php if(isset($user['treatments']) && $user['treatments'] != 0){ echo htmlentities(trim($user['treatments']));} ?>" placeholder="Treatments" />
						</div>
																	
						<div class="gift paddingbtm">
							<div class="lable">Survivor Group</div>
							<input type="text" class="fullinput" name="survivor_group" value="<?php if(isset($user['survivor_group']) && $user['survivor_group'] != 0){ echo htmlentities(trim($user['survivor_group']));} ?>" placeholder="Survivor Group" />
						</div>
						<div class="clear"></div>
					
						<div class="gift paddingbtm">
							<div class="lable">Healing Interest</div>
							 <select class="fullinput" name="healing_interest" >
							 	<option value="">Select</option>
							<?php	foreach($healing_interest as $val) { ?>
								<option value="<?php echo $val; ?>"  <?php if(isset($user['healing_interest']) && $user['healing_interest'] == $val) { echo "selected='selected'"; }?> ><?php echo $val; ?></option>
							<?php } ?>
							</select>	
						</div>
						<div class="clear"></div>	
						<div class="gift paddingbtm">
							<div class="lable">Stroke Type</div>
							 
							 <select class="fullinput" name="stroke_type" >
							 	<option value="">Select</option>
							<?php	foreach($stroke_type as $val) { ?>
								<option value="<?php echo $val; ?>"  <?php if(isset($user['stroke_type']) && $user['stroke_type'] == $val) { echo "selected='selected'"; }?> ><?php echo $val; ?></option>
							<?php } ?>
							</select>	
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Stroke Location</div>
							 <select class="fullinput" name="stroke_location" >
							 	<option value="">Select</option>
							<?php	foreach($stroke_location as $val) { ?>
								<option value="<?php echo $val; ?>"  <?php if(isset($user['stroke_location']) && $user['stroke_location'] == $val) { echo "selected='selected'"; }?> ><?php echo $val; ?></option>
							<?php } ?>
							</select>	
						</div>
					
						<div class="clear"></div>		
						<div class="gift paddingbtm">
							<div class="lable">Symptoms</div>
							<input type="hidden" name="symptoms_id[]" value="<?php if(isset($symptoms[0]['id']) && $symptoms[0]['id'] != ""){ echo $symptoms[0]['id'];} ?>" />
							 <select class="fullinput symptoms" name="symptoms[]" onchange=" return getVal(this.value,1);" >
							 	<option value="">Select</option>
							 	<option value="cognitive"  <?php if(isset($symptoms[0]['symptoms']) && $symptoms[0]['symptoms'] == "cognitive") { echo "selected='selected'"; }?>>Cognitive</option>
							 	<option value="emotional"  <?php if(isset($symptoms[0]['symptoms']) && $symptoms[0]['symptoms'] == "emotional") { echo "selected='selected'"; }?>>Emotional</option>
								<option value="physical" <?php if(isset($symptoms[0]['symptoms']) && $symptoms[0]['symptoms'] == "physical") { echo "selected='selected'"; }?>>Physical</option>												
							</select>	
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Symptoms Detail</div>
							 <select class="fullinput" name="symptoms_value[]" id="symptoms_value_1" >
							 	<?php 
							 		if(isset($symptoms[0]['symptoms']) && $symptoms[0]['symptoms'] == "physical") 
							 		{
								 			
								 		 foreach($physical as $val)
										 { 
										 ?>
										 
										 	<option value="<?php echo $val; ?>"  <?php if(isset($symptoms[0]['symptoms_value']) && $symptoms[0]['symptoms_value'] == $val) { echo "selected='selected'"; }?> > <?php echo $val; ?> </option>
											 		
										 <?php
				 								
										 }
							 		 }
									 else if(isset($symptoms[0]['symptoms']) && $symptoms[0]['symptoms'] == "cognitive")		
									 {
									 	
												
											 foreach($cognitive as $val)
											 {
											 		?>
											 		<option value="<?php echo $val; ?>"  <?php if(isset($symptoms[0]['symptoms_value']) && $symptoms[0]['symptoms_value'] == $val) { echo "selected='selected'"; }?> > <?php echo $val; ?> </option>
											 		<?php
											 }	
																	 	
									 }		
									 else if(isset($symptoms[0]['symptoms']) && $symptoms[0]['symptoms'] == "emotional")		
									 {	
									 	 
						
											 foreach($emotional as $val)
											 {
											 	?>
											 		<option value="<?php echo $val; ?>"  <?php if(isset($symptoms[0]['symptoms_value']) && $symptoms[0]['symptoms_value'] == $val) { echo "selected='selected'"; }?> > <?php echo $val; ?> </option>
											 		
											 	<?php
											 }
									 }	
									 else
									 {
											echo "<option value=''>Select</option>";									 	
  								 	 }
  								 	 	 		 
							 	?>
													
							</select>	
						</div>
						<div class="clear"></div>
					
						<div class="clear"></div>
						<div class="gift paddingbtm">
							<div class="lable">Symptoms</div>
							 <input type="hidden" name="symptoms_id[]" value="<?php if(isset($symptoms[1]['id']) && $symptoms[1]['id'] != ""){ echo $symptoms[1]['id'];} ?>" />
							 <select class="fullinput symptoms" name="symptoms[]" onchange="return getVal(this.value,2);" >
							 	<option value="">Select</option>
								<option value="physical" <?php if(isset($symptoms[1]['symptoms']) && $symptoms[1]['symptoms'] == "physical") { echo "selected='selected'"; }?>>Physical</option>
								<option value="cognitive"  <?php if(isset($symptoms[1]['symptoms']) && $symptoms[1]['symptoms'] == "cognitive") { echo "selected='selected'"; }?>>Cognitive</option>	
								<option value="emotional"  <?php if(isset($symptoms[1]['symptoms']) && $symptoms[1]['symptoms'] == "emotional") { echo "selected='selected'"; }?>>Emotional</option>	
							</select>	
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Symptoms Detail</div>
							 <select class="fullinput" name="symptoms_value[]" id="symptoms_value_2" >
							 
							 	<?php 
							 		if(isset($symptoms[1]['symptoms']) && $symptoms[1]['symptoms'] == "physical") 
							 		{
								 		 foreach($physical as $val)
										 { 
										 ?>
										 
										 	<option value="<?php echo $val; ?>"  <?php if(isset($symptoms[1]['symptoms_value']) && $symptoms[1]['symptoms_value'] == $val) { echo "selected='selected'"; }?> > <?php echo $val; ?> </option>
											 		
										 <?php
				 								
										 }
							 		 }
									 else if(isset($symptoms[1]['symptoms']) && $symptoms[1]['symptoms'] == "cognitive")		
									 {
									 		 foreach($cognitive as $val)
											 {
											 		?>
											 		<option value="<?php echo $val; ?>"  <?php if(isset($symptoms[1]['symptoms_value']) && $symptoms[1]['symptoms_value'] == $val) { echo "selected='selected'"; }?> > <?php echo $val; ?> </option>
											 		<?php
											 }	
																	 	
									 }		
									 else if(isset($symptoms[1]['symptoms']) && $symptoms[1]['symptoms'] == "emotional")		
									 {	
									 	 	 foreach($emotional as $val)
											 {
											 	?>
											 		<option value="<?php echo $val; ?>"  <?php if(isset($symptoms[1]['symptoms_value']) && $symptoms[1]['symptoms_value'] == $val) { echo "selected='selected'"; }?> > <?php echo $val; ?> </option>
											 		
											 	<?php
											 }
									 }	
									 else
									 {
											echo "<option value=''>Select</option>";									 	
									 }	 		 
						 		  ?>
													
							</select>	
						</div>
						<?php
								if(count($symptoms) > 2)
								{
									for($i=2;$i<count($symptoms);$i++) 
									{
						?>
											<div class="clear"></div>
											<div class="gift paddingbtm">
												<div class="lable">Symptoms</div>
												 <input type="hidden" name="symptoms_id[]" value="<?php if(isset($symptoms[$i]['id']) && $symptoms[$i]['id'] != ""){ echo $symptoms[$i]['id'];} ?>" />
												 <select class="fullinput symptoms" name="symptoms[]" onchange="return getVal(this.value,<?php echo $i; ?>);" >
												 	<option value="">Select</option>
													<option value="physical" <?php if(isset($symptoms[$i]['symptoms']) && $symptoms[$i]['symptoms'] == "physical") { echo "selected='selected'"; }?>>Physical</option>
													<option value="cognitive"  <?php if(isset($symptoms[$i]['symptoms']) && $symptoms[$i]['symptoms'] == "cognitive") { echo "selected='selected'"; }?>>Cognitive</option>	
													<option value="emotional"  <?php if(isset($symptoms[$i]['symptoms']) && $symptoms[$i]['symptoms'] == "emotional") { echo "selected='selected'"; }?>>Emotional</option>	
												</select>	
											</div>
											
											<div class="gift paddingbtm">
												<div class="lable">Symptoms Detail</div>
												 <select class="fullinput" name="symptoms_value[]" id="symptoms_value_<?php echo $i; ?>" >
												 
												 	<?php 
												 		if(isset($symptoms[$i]['symptoms']) && $symptoms[$i]['symptoms'] == "physical") 
												 		{
													 		 foreach($physical as $val)
															 { 
															 ?>
															 
															 	<option value="<?php echo $val; ?>"  <?php if(isset($symptoms[$i]['symptoms_value']) && $symptoms[$i]['symptoms_value'] == $val) { echo "selected='selected'"; }?> > <?php echo $val; ?> </option>
																 		
															 <?php
									 								
															 }
												 		 }
														 else if(isset($symptoms[$i]['symptoms']) && $symptoms[$i]['symptoms'] == "cognitive")		
														 {
														 		 foreach($cognitive as $val)
																 {
																 		?>
																 		<option value="<?php echo $val; ?>"  <?php if(isset($symptoms[$i]['symptoms_value']) && $symptoms[$i]['symptoms_value'] == $val) { echo "selected='selected'"; }?> > <?php echo $val; ?> </option>
																 		<?php
																 }	
																						 	
														 }		
														 else if(isset($symptoms[$i]['symptoms']) && $symptoms[$i]['symptoms'] == "emotional")		
														 {	
														 	 	 foreach($emotional as $val)
																 {
																 	?>
																 		<option value="<?php echo $val; ?>"  <?php if(isset($symptoms[$i]['symptoms_value']) && $symptoms[$i]['symptoms_value'] == $val) { echo "selected='selected'"; }?> > <?php echo $val; ?> </option>
																 		
																 	<?php
																 }
														 }	
														 else
														 {
																echo "<option value=''>Select</option>";									 	
														 }	 		 
											 		  ?>
																		
												</select>	
											</div>		
						<?php				
									}	
									
								} 
						?>
						<div id="addMore"></div>
						<div class="gift paddingbtm">
							<div class="lable" style="margin-top:30px;"><a href="javascript:void(0)" onclick="addMoreElement()">Add More..</a></div>		
						</div>
							
				</div>	<!--- Medical History Over -->
				
				<div class="clear"></div>
				
				<div id="professionalhistory" style="display:none"  > <!--- Professional History Start -->	
						<?php
								$classification = array("Administrator"=>"Administrator",
													"Certified Professional in Healthcare Quality"=>"Certified Professional in Healthcare Quality",
													"EMT or Paramedics"=>"EMT or Paramedics",
													"Non-Healthcare professional"=>"Non-Healthcare professional",
													"Nurse"=>"Nurse",
													"Nurse Scientist"=>"Nurse Scientist",
													"Occupational Therapist"=>"Occupational Therapist",
													"Other Healcare Professional"=>"Other Healcare Professional",
													"Pharmacist"=>"Pharmacist",
													"Physical Therapist"=>"Physical Therapist",
													"Physician"=>"Physician",
													"Physician Assistant"=>"Physician Assistant",
													"Registered Dietician"=>"Registered Dietician",
													"Research Scientist"=>"Research Scientist",
													"Respiratory Therapist"=>"Respiratory Therapist",
													"Speech Therapist"=>"Speech Therapist",
													"Technician or Technologist"=>"Technician or Technologist",
													"Acupuncturist"=>"Acupuncturist",
													"Tai-chi Specialist"=>"Tai-chi Specialist",
													"Guided Image Specialist"=>"Guided Image Specialist",
													"Massage Therapist"=>"Massage Therapist",
													"Hippotherapist"=>"Hippotherapist",
													"Psychologist"=>"Psychologist",
													"Other Professionals"=>"Other Professionals"); 
						sort($classification);							
						$professional_specialty=array(
													"Administration"=>"Administration",
													"Allergy & Immunization"=>"Allergy & Immunization",
													"Anatomy"=>"Anatomy",
													"Anesthesiology"=>"Anesthesiology",
													"Arteriosclerosis"=>"Arteriosclerosis",
												   "Behavioral Science/Medicine"=>"Behavioral Science/Medicine",
													"Biochemistry"=>"Biochemistry",
													"Biological Sciences"=>"Biological Sciences",
													"Biophysics"=>"Biophysics",
													"Cardiology: CV Radiology"=>"Cardiology: CV Radiology",
													"Cardiology: Clinical EP"=>	"Cardiology: Clinical EP",
													"Cardiology: Echocardiography"=>"Cardiology: Echocardiography",
													"Cardiology: General Cardiology"=>"Cardiology: General Cardiology",
													"Cardiology: Heart Failures"=>"Cardiology: Heart Failures",
													"Cardiology: Imaging"=>"Cardiology: Imaging",
													"Cardiology: Intervention"=>"Cardiology: Intervention",
													"Cardiology: Pediatric"=>"Cardiology: Pediatric",
													"Cardiology: Prevention"=>"Cardiology: Prevention",
													"Cardiology: Transplantation"=>"Cardiology: Transplantation",
													"Cell Biology"=>"Cell Biology",
												   "Chemistry"=>"Chemistry",
													"Clinical Pharmacology"=>"Clinical Pharmacology",
													"Critical Care"=>"Critical Care",
													"Diabetes & Metabolism"=>"Diabetes & Metabolism",
													"Diatectics"=>"Diatectics",
													"Emercency Medicine"=>"Emercency Medicine",
													"Endocrinology"=>"Endocrinology",
													"Epidemiology"=>"Epidemiology",
													"Family Practice"=>"Family Practice",
													"Genetics"=>"Genetics",
													"Gerontology"=>"Gerontology",
													"Hematology"=>"Hematology",
													"Hypertension"=>"Hypertension",
													"Infectious Diseases"=>"Infectious Diseases",
													"Internal Medicine"=>"Internal Medicine",
													"Interventional Radiology"=>"Interventional Radiology",
													"Microbiology"=>"Microbiology",
													"Molecular biology"=>"Molecular biology",
													"Nephrology"=>"Nephrology",
													"Neurology: Imaging"=>"Neurology: Imaging",
													"Neurology: Radiology"=>"Neurology: Radiology",
													"Neuology: Speech language path"=>"Neuology: Speech language path",
													"Neurology: Stroke"=>"Neurology: Stroke",
													"Neuro-surgery"=>"Neuro-surgery",
													"Nuclear medicine"=>"Nuclear medicine",
													"Nutrition"=>"Nutrition",
													"Obstetrics and Gynecology"=>"Obstetrics and Gynecology",
													"Occupational Health"=>"Occupational Health",
													"Occupational Therapy"=>"Occupational Therapy",
													"Pathology"=>"Pathology",
													"Pediatrics"=>"Pediatrics",
													"Pharmacology"=>"Pharmacology",
													"Pharmacy"=>"Pharmacy",
													"Physiology"=>"Physiology",
													"Pulmonary Medicine"=>"Pulmonary Medicine",
													"Radiology"=>"Radiology",
													"Rehab: Cardiac"=>"Rehab: Cardiac",
													"Rehab: Physical Therapy"=>"Rehab: Physical Therapy",
													"Rehab: Physiology"=>"Rehab: Physiology",
													"Rehab: Rehab medicine"=>"Rehab: Rehab medicine",
													"Rehab: Stroke"=>"Rehab: Stroke",
													"General Surgery"=>"General Surgery",
													"Cardio Surgery"=>"Cardio Surgery",
													"Trauma Surgery"=>"Trauma Surgery",
													"Vascular Surgery"=>"Vascular Surgery",
													"Thrombosis"=>"Thrombosis",
													"Vascular Medicine"=>"Vascular Medicine"
								
							);
							sort($professional_specialty); 
						?>			
						<div class="gift paddingbtm">
							<div class="lable">Years of Practice</div>
							<input type="text" class="fullinput" name="years_of_practice" value="<?php if(isset($user['years_of_practice']) && $user['years_of_practice'] != 0){ echo htmlentities(trim($user['years_of_practice']));} ?>" placeholder="Years of Practice" />
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Specialties</div>
							<input type="text" class="fullinput" name="specialties" value="<?php if(isset($user['specialties']) && $user['specialties'] != 0){ echo htmlentities(trim($user['specialties']));} ?>" placeholder="Specialties" />
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Functions</div>
							<input type="text" class="fullinput" name="functions" value="<?php if(isset($user['functions']) && $user['functions'] != 0){ echo htmlentities(trim($user['functions']));} ?>" placeholder="Functions" />
						</div>
						<div class="clear"></div>
						<div class="gift paddingbtm">
							<div class="lable">Classification</div>
							<select name="classification" class="fullinput">
							<option value="">Select</option>							
							<?php foreach($classification as $val) { ?>
								<option value="<?php echo $val; ?>"  <?php if(isset($user['classification']) && $user['classification'] == $val) { echo "selected='selected'"; }?> > <?php echo $val; ?></option>
								
							<?php } ?>
							</select>					
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Professional Specialty(1)</div>
						 <select class="fullinput" name="professional_specialty_one" >
						  <option value="">Select</option>
							<?php	foreach($professional_specialty as $val) { ?> 
								<option value="<?php echo $val; ?>" <?php if(isset($user['professional_specialty_one']) && $user['professional_specialty_one'] == $val) { echo "selected='selected'"; }?> ><?php echo $val; ?></option>
							<?php } ?>
							</select>													
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Professional Specialty(2)</div>
							 <select class="fullinput" name="professional_specialty_two" >
							 <option value="">Select</option>
							<?php	foreach($professional_specialty as $val) { ?>
								<option value="<?php echo $val; ?>"  <?php if(isset($user['professional_specialty_two']) && $user['professional_specialty_two'] == $val) { echo "selected='selected'"; }?> ><?php echo $val; ?></option>
							<?php } ?>
							</select>	
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Professional Specialty(3)</div>
							 <select class="fullinput" name="professional_specialty_three" >
							 <option value="">Select</option>
							<?php	foreach($professional_specialty as $val) { ?>
								<option value="<?php echo $val; ?>"  <?php if(isset($user['professional_specialty_three']) && $user['professional_specialty_three'] == $val) { echo "selected='selected'"; }?> ><?php echo $val; ?></option>
							<?php } ?>
							</select>	
						</div>
				</div>	<!--- Professional History Start -->
				
				<div class="clear"></div>
				<div id="addresscontact" style="display:none"> <!-- Address Contact Start-->
						<div class="fullfild fildspace">
							<div class="lable">Address</div>
							<input type="text" class="fullinput"  name="address" value="<?php if(isset($user['address']) && $user['address'] != 0){ echo htmlentities(trim($user['address']));} ?>" placeholder="Enter Address" />
						</div>
						
						<div class="clear"></div>
				
						<div class="gift paddingbtm">
							<div class="lable">City</div>
							<input type="text" class="fullinput" name="city" value="<?php if(isset($user['city'])){ echo htmlentities(trim($user['city']));} ?>" placeholder="City" />
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">State</div>
							<input type="text" class="fullinput" name="state" value="<?php if(isset($user['state'])){ echo htmlentities(trim($user['state']));} ?>" placeholder="State" />
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Telephone</div>
							<input type="text" class="fullinput" name="telephone" value="<?php if(isset($user['telephone']) && $user['telephone'] != 0){ echo htmlentities(trim($user['telephone']));} ?>" placeholder="Telephone" />
						</div>
				</div> <!-- Address Contact End-->
				
				<div class="clear"></div>
				
				<div id="socialinfo" style="display:none">  <!-- Social Information Start-->
						<div class="gift paddingbtm">
							<div class="lable">Google PlusID</div>
							<input type="text" class="fullinput" name="googleplus_id" value="<?php if(isset($user['googleplus_id'])){ echo htmlentities(trim($user['googleplus_id']));} ?>" placeholder="Google PlusID" />
						</div>				
						
						<div class="gift paddingbtm">
							<div class="lable">Skype ID</div>
							<input type="text" name="skype_id" value="<?php if(isset($user['skype_id'])) { echo htmlentities(trim($user['skype_id'])); }  ?>" class="fullinput" placeholder="Skype ID" />
						</div>
						<div class="clear sep"></div>
						
						
						<div class="gift paddingbtm">
							<div class="lable">Web Sites</div>
							<input type="text" class="fullinput" name="web_sites" value="<?php if(isset($user['web_sites'])){ echo htmlentities(trim($user['web_sites']));} ?>" placeholder="Web Sites" />
						</div>
						
						<div class="gift paddingbtm">
							<div class="rrs-blog">
								<div class="lable">Rss Blog Feed Url</div>
								<input type="text" class="fullinput" name="rss_blog_url[]" value="<?php if(isset($rss_blog_url[0]['rss_blog_url'])){ echo trim($rss_blog_url[0]['rss_blog_url']);} ?>" placeholder="Rss Blog Feed Url" />
								<?php 
										if(isset($rss_blog_url[0]['rss_blog_url']))
										{ 
								?>
											<input type="hidden" name="rss_blog_url_id[]" value="<?php echo $rss_blog_url[0]['id'] ?>"  />
								<?php			
										} 
								?>
							</div>
							<br>
							<?php
								 if(count($rss_blog_url) > 1)
								 {
								 		for($i=1;$i<count($rss_blog_url);$i++) 
										{
							?>
											<div class="rrs-blog">
												<div class="lable">Rss Blog Feed Url</div>
												<input type="text" class="fullinput" name="rss_blog_url[]" value="<?php echo $rss_blog_url[$i]['rss_blog_url'] ?>" placeholder="Rss Blog Feed Url" />
												<input type="hidden" name="rss_blog_url_id[]" value="<?php echo $rss_blog_url[$i]['id'] ?>"  />
											</div>
											<br>			
							<?php 	 			
								 		}
								 } 
							?>
							<div id="addmorerss">
							
							</div>	
						</div>
						<div class="gift paddingbtm">
								<div class="lable">&nbsp;</div>
								<a href="javascript:void(0);" onclick="addRss()">Add More</a>
						</div>
				</div> 						<!-- Social Information End-->
				
				<div id="volunteer" style="display:none">
						<div class="fullfild fildspace">
							<div class="lable">Volunteer Resume</div>
							<textarea name="volunteer_resume" cols="50" class="fullinput"><?php if(isset($user['volunteer_resume'])){ echo htmlentities(trim($user['volunteer_resume']));} ?></textarea>
						</div>
						
						<div class="clear"></div>
				
						<div class="gift paddingbtm">
							<div class="lable">Reference Name</div>
							<input type="text" class="fullinput" name="reference_name" value="<?php if(isset($user['reference_name'])){ echo $user['reference_name']; } ?>" placeholder="Reference Name" />
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Reference Contact Info</div>
							<input type="text" class="fullinput" name="reference_contact_info" value="<?php if(isset($user['reference_contact_info'])){ echo $user['reference_contact_info'];} ?>" placeholder="Reference Contact Info" />
						</div>
						
						<div class="gift paddingbtm">
							<div class="lable">Reference Email</div> 
							<input type="text" class="fullinput" name="reference_email" value="<?php if(isset($user['reference_email'])){ echo $user['reference_email'];} ?>" placeholder="Reference Email" />
						</div>
						
				</div>
				<div class="clear"></div>
				
				
				<div class="buttonmain fullfild">
					<input type="submit" class="button3" value="Save" name="test">
					<a href="<?php echo base_url('account/changepassword');?>">Change Password</a>
					<!--<input type="button" class="button3" value="Cancel" name="test">-->
				</div>
				
				
			<?php echo form_close(); ?>
			</div>	  
		
		</div>
	
      </div>
	  
    </div>
</div>
<div class="clear sep"></div>
<script type="text/javascript" src="<?php echo base_url('assets/js/vendors/user.js'); ?>"></script>