<div class="sep"></div>
<div class="main">
	<div class="frmmid">

		<div class="frmtit">Register</div>
		<div class="frmpedd">
				<?php echo $this->load->view('common/message'); ?>
			<?php
				$attributes = array('id' => 'add_form', 'name' => 'add_form', 'method'=>'POST','enctype'=>"multipart/form-data");				   	
				echo form_open(base_url('home/do_register'),$attributes); ?>
						<input type="hidden" name="mode" value="<?php echo $mode?>">
						<input type="hidden" name="id" value="<?php if(isset($user['id'])){ echo htmlentities(trim($user['id']));} ?>">
				  		  <div class="frmlbl">User Name</div>
				    			<input type="text" class="frmfild" name="user_name" id="exampleInputEmail1" value="<?php if(isset($user['user_name'])){ echo htmlentities(trim($user['user_name']));} ?>">
				  			
				   		<div class="frmlbl">First Name </div>
				    			<input type="text" class="frmfild" name="first_name" id="exampleInputEmail1"  value="<?php if(isset($user['first_name'])){ echo htmlentities(trim($user['first_name']));} ?>">
				  			
				  		   <div class="frmlbl">Last Name </div>
				    			<input type="text" class="frmfild" name="last_name" id="exampleInputEmail1"  value="<?php if(isset($user['last_name'])){ echo htmlentities(trim($user['last_name']));} ?>">
				  			
				  			 <div class="frmlbl">Gender </div>
				    			<input type="text" class="frmfild" name="gender" id="exampleInputEmail1"  value="<?php if(isset($user['gender'])){ echo htmlentities(trim($user['gender']));} ?>">
				  			
				  			
				    		<div class="frmlbl">Email</div>
				    			<input type="text" name="email"  class="frmfild" id="exampleInputEmail1"  value="<?php if(isset($user['email'])){ echo htmlentities(trim($user['email']));} ?>">
				  	
				  			<?php if($mode=="add")
							{
							?>
				    		<div class="frmlbl">Password</div>
				    		<input type="password" name="password" class="frmfild" id="exampleInputPassword1"  >
							<?php } else {?>
							<div class="frmlbl">profile picture</div>
							<input id="upload_file" type="file" class="form-control" id="image" name="image">
							<input type="hidden" value="<?php echo $user['profile_picture']; ?>" class="form-control" id="current_image" name="current_image">
                      
							<?php } ?>
							<div class="frmlbl">Dob</div>
				    		<input type="text" name="dob" class="frmfild" id="exampleInputPassword1"  >
							<div class="frmlbl">Phone no</div>
				    		<input type="text" name="phone_no" class="frmfild" id="exampleInputPassword1"  >
				  
				  			
				  			<div class="buttonmain">
				  				<button type="submit" class="button" id="submit_register">Register</button>
				  				
				  			</div>
				  		
						<?php echo form_close(); ?>
				 </div>
	</div>  
</div>
<div class="sep"></div>
