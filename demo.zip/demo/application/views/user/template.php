<!DOCTYPE html>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en-US"><![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8" lang="en-US"><![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9" lang="en-US"><![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en-US">
<!--<![endif]-->
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>demo</title>
<link rel="profile" href="http://gmpg.org/xfn/11">

<meta name="robots" content="noindex,follow">
<link rel="stylesheet" id="theme_stylesheet-css" href="<?php echo base_url('assets/css/style.css');?>" type="text/css" media="all">
<link rel="stylesheet" id="google_fonts-css" href="<?php echo base_url('assets/css/pagination.css');?>" type="text/css" media="all">
<link rel="stylesheet" href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css'); ?>">
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery-1.11.1.min.js');?>"></script>
<link rel="stylesheet" id="google_fonts-css" href="<?php echo base_url('assets/css/new-styles.css');?>" type="text/css" media="all">
<link rel="stylesheet" href="<?php echo base_url('assets/css/menu.css');?>">
<script type="text/javascript" src="<?php echo base_url('assets/js/menu.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/vendors/common.js');?>"></script>
<style>
.container { max-width: 1200px; }
</style>
<?php 	echo $this->assets_load->print_assets('header');  ?>	
		
</head>
<body>

<div id="page">
			<?php echo $header; ?>
			<?php  echo $content; ?>
			<?php echo $footer; ?>
</div>

<?php 	echo $this->assets_load->print_assets('footer');  ?>
	
<script language="javascript">APPLICATION_URL="<?php echo base_url(); ?>"</script>
</div>
</body>
</html>