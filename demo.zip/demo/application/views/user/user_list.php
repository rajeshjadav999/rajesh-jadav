<div id="main" style="min-height:708px;">
    <div class="container" >
      <div class="row">
	  	<div class="col01 center">
        <TABLE>
   <TR>
      <TD>First Name</TD>
      <TD>Last Name</TD>
	  <TD>Email</TD>
	  <TD>User Name</TD>
	  <TD>Action</TD>
	   <TD>Action</TD>
	
   </TR>
   <?php
	foreach($user_list as $row)
	{ 
					
   ?>
   <TR>
      <TD><?php echo $row['first_name'] ?></TD>
	   <TD><?php echo $row['last_name'] ?></TD>
	    <TD><?php echo $row['email'] ?></TD>
		<TD><?php echo $row['user_name'] ?></TD>
		 <TD><a href="javascript:void(0)" onclick="delete_data(<?php echo $row['id'] ?>)">delete</a></TD>
		  <TD><a href="<?php echo base_url('home/edit/') ?>/<?php echo $row['id'] ?>">edit</a></TD>
	  
    
   </TR>
   <?php } ?>
</TABLE>
			
		</div>
		
		
      </div>
    </div>
  </div>
  
  <script type="text/javascript">
function delete_data(id){
	var url  = APPLICATION_URL+"home/delete_record/"+id;
	jQuery.ajax({
				url : url ,
				method : 'get',
				success : function(data){
				
					alert("Delete success");
					location.reload();
				}
			});
}
</script>
  <!-- #main -->