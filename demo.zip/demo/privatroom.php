<?php
		/*$ch = curl_init(); 
		$req_url = 'https://api.iflychat.com/api/1.0/room/create'; 
		 
		curl_setopt($ch, CURLOPT_URL, $req_url); 
		 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
		 
		curl_setopt($ch, CURLOPT_POST, true); 
		 
		curl_setopt($ch, CURLOPT_POSTFIELDS, 'api_key=48bbR-TgQeVZdMGFbUEdoLIX11XlHS1QmMzjgSqcjYwW24860&room_name=WohaulaTest&room_role=2&room_private=1'); 
		 
		$result = curl_exec($ch); 
		 
		curl_close($ch); 
		
		print_r($result);*/

//c-61,c-62,c-63,c-64,c-66,c-67,c-69,c-70,c-73,c-41,c-43,c-58,c-59,c-74,c-75
		$ch = curl_init(); 
 
		$req_url = 'https://api.iflychat.com/api/1.0/rooms/list'; 
 
		curl_setopt($ch, CURLOPT_URL, $req_url); 
 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
 
		curl_setopt($ch, CURLOPT_POST, true); 
 
		curl_setopt($ch, CURLOPT_POSTFIELDS, 'api_key=48bbR-TgQeVZdMGFbUEdoLIX11XlHS1QmMzjgSqcjYwW24860'); 
 
		$result = curl_exec($ch); 
 
		curl_close($ch);
 
		$result = json_decode($result);
		
		echo "<pre>";
			print_r($result);
		echo "</pre>";

		
	
?>