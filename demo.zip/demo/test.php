<?php
$targetArray = array("Sara","Cindy","Julie","Megan");
$rand = array_rand($targetArray,3);
print_r($rand);
echo $targetArray[$rand[0]];
echo $targetArray[$rand[1]];
echo $targetArray[$rand[2]];
?>

